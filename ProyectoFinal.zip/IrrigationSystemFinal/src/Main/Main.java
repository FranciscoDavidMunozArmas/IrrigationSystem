package Main;

import Classes.ArduinoInit;
import Controller.Controller;
import IrrigationInterface.IrrigationInterface;
import Model.ArduinoDAO;

public class Main {

    public static void main(String[] args) {
        IrrigationInterface view = new IrrigationInterface();
        ArduinoDAO dao = new ArduinoDAO();
        ArduinoInit arduino = new ArduinoInit();
        Controller control = new Controller(view, dao, arduino);
    }
    
}
