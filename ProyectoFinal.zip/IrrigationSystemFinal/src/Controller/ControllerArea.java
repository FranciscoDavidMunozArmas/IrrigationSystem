package Controller;

import Classes.ArduinoInit;
import Classes.Area;
import Classes.AreaCircle;
import Classes.AreaRectangle;
import Classes.AreaTriangle;
import Classes.FlowForArduino;
import Classes.Plants;
import Classes.Time;
import IrrigationInterface.IrrigationInterface;
import Model.ArduinoDAO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
//Controlador de la interfaz del area

public class ControllerArea implements ActionListener {

    private IrrigationInterface view;
    private ArduinoDAO dao;
    private ArduinoInit arduino;

    public ControllerArea(IrrigationInterface view, ArduinoDAO dao, ArduinoInit arduino) {
        this.view = view;
        this.dao = dao;
        this.arduino = arduino;
        this.view.mainArea.selArea.btnCircle.addActionListener(this);
        this.view.mainArea.selArea.btnTriangle.addActionListener(this);
        this.view.mainArea.selArea.btnRectangle.addActionListener(this);
        this.view.mainArea.btnNext.addActionListener(this);
        this.view.mainArea.conteiner.add(view.mainArea.selArea);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if ((e.getSource().equals(view.mainArea.selArea.btnTriangle)) || (e.getSource().equals(view.mainArea.selArea.btnCircle)) || (e.getSource().equals(view.mainArea.selArea.btnRectangle))) {
            view.mainArea.btnNext.setEnabled(true);
        }

        if (e.getSource().equals(view.mainArea.selArea.btnCircle)) {
            view.mainArea.selArea.setAreaSelection(1);
            setTextForCircle();
            view.mainArea.btnSteps = 1;
            view.mainArea.activatePanels();
        }

        if (e.getSource().equals(view.mainArea.selArea.btnRectangle) || e.getSource().equals(view.mainArea.selArea.btnTriangle)) {
            setTextForRectangleTriangle();
            view.mainArea.btnSteps = 1;
            view.mainArea.activatePanels();
            figureChoosen(e);
        }

        if ((view.mainArea.btnSteps == 3) && (e.getSource().equals(view.mainArea.btnNext))) {
            if (!proveFillFields()) {
                int minutes = getTotalMinutes();
                double litres = FlowForArduino.getFlow(getLitresForPlants(), areaCalculate(), minutes);
                dao.postArduino(litres, view.mainArea.time.getHourS(), view.mainArea.time.getMinuteS(), view.mainArea.time.getHourE(), view.mainArea.time.getMinuteE());
                if (arduino.arduinoStartSend()) {
                    String sendData = litres + "%" + view.mainArea.time.getHourS() + "%" + view.mainArea.time.getMinuteS() + "%" + view.mainArea.time.getHourE() + "%" + view.mainArea.time.getMinuteE();
                    arduino.arduinoSendData(sendData);
                    arduino.arduinoClose();
                }

                setZero();
                setPanels(-1);
            }

        }
    }

    //Activacion de los campos de texto para el circulo
    private void setTextForCircle() {
        view.mainArea.sizeSet.txtHeight.setText("1");
        view.mainArea.sizeSet.txtHeight.setVisible(false);
        view.mainArea.sizeSet.lbHeight.setVisible(false);
    }

    //Activacion de los campos de texto para el triangulo y rectangulo
    private void setTextForRectangleTriangle() {
        view.mainArea.sizeSet.txtHeight.setText("");
        view.mainArea.sizeSet.txtHeight.setVisible(true);
        view.mainArea.sizeSet.lbHeight.setVisible(true);
    }

    private void figureChoosen(ActionEvent e) {
        if (e.getSource().equals(view.mainArea.selArea.btnRectangle)) {
            view.mainArea.selArea.setAreaSelection(0);
        } else if (e.getSource().equals(view.mainArea.selArea.btnTriangle)) {
            view.mainArea.selArea.setAreaSelection(2);
        }
    }

    //Obtencion del area de la figura
    private double areaCalculate() {
        double area = 0;
        if (view.mainArea.selArea.getAreaSelection() == 0) {
            area = getAreaForRectangle();
        } else if (view.mainArea.selArea.getAreaSelection() == 1) {
            area = getAreaForCircle();
        } else if (view.mainArea.selArea.getAreaSelection() == 2) {
            area = getAreaForTriangle();
        }
        return area;
    }

    //Obtencion del area de un rectangulo
    private double getAreaForRectangle() {
        Area fig = null;
        fig = new AreaRectangle(Double.parseDouble(view.mainArea.sizeSet.txtHeight.getText()), Double.parseDouble(view.mainArea.sizeSet.txtBase.getText()));
        return fig.area();
    }

    //Obtencion del area de un triangulo
    private double getAreaForTriangle() {
        Area fig = null;
        fig = new AreaTriangle(Double.parseDouble(view.mainArea.sizeSet.txtHeight.getText()), Double.parseDouble(view.mainArea.sizeSet.txtBase.getText()));
        return fig.area();
    }

    //Obtencion del area de un circulo
    private double getAreaForCircle() {
        Area fig = null;
        fig = new AreaCircle(Double.parseDouble(view.mainArea.sizeSet.txtBase.getText()));
        return fig.area();
    }

    //Obtencion de litros
    private double getLitresForPlants() {
        Plants plant = new Plants();
        double litres = 0;
        if (view.mainArea.plants.cbGrass.isSelected()) {
            litres += plant.getLitresPerGrassOrVariousTypeOfPlants();
        }

        if (view.mainArea.plants.cbSmallTrees.isSelected()) {
            litres += plant.getLitresPerGrassOrVariousTypeOfPlants();
        }

        if (view.mainArea.plants.cbTrees.isSelected()) {
            litres += plant.getLitresPerTree();
        }

        if (view.mainArea.plants.cbSmallTrees.isSelected()) {
            litres += plant.getLitresPerShortTree();
        }

        return litres;
    }

    //Verficacion de lo campos ---> Verifica que los campos no esten vacios
    private boolean proveFillFields() {
        boolean a = false;
        if ((view.mainArea.sizeSet.txtBase.getText().equals("")) || (view.mainArea.sizeSet.txtHeight.getText().equals(""))) {
            JOptionPane.showMessageDialog(null, "NO SE HA INTRODUCIDO UNA MEDIA");
            setPanels(0);
            a = true;
        } else if (!view.mainArea.plants.cbGrass.isSelected() && !view.mainArea.plants.cbSmallTrees.isSelected() && !view.mainArea.plants.cbTrees.isSelected() && !view.mainArea.plants.cbVariousPlants.isSelected()) {
            JOptionPane.showMessageDialog(null, "DEBE SELECCIONAR AL MENOS UN TIPO DE PLANTA");
            setPanels(2);
            a = true;
        } else if (getTotalMinutes() < 30) {
            JOptionPane.showMessageDialog(null, "LA DIFERENCIA DE TIEMPO MINIMA ES DE 30 MINUTOS");
            setPanels(1);
            a = true;
        } else if (isAlphaCharacter(view.mainArea.sizeSet.txtBase.getText()) || isAlphaCharacter(view.mainArea.sizeSet.txtHeight.getText())) {
            JOptionPane.showMessageDialog(null, "SE HAN COLOCADO LETRAS");
            setPanels(0);
            a = true;
        }
        return a;
    }

    //Obtencion de los mintutos totales ---> Diferencia entre el inicio y fin
    private int getTotalMinutes() {
        int startTime = Time.toMinutes(view.mainArea.time.getHourS(), view.mainArea.time.getMinuteS());
        int endTime = Time.toMinutes(view.mainArea.time.getHourE(), view.mainArea.time.getMinuteE());
        return Time.getDiference(startTime, endTime);
    }

    //Verificacion de que todos lo caracteres sean alfabeticos
    private boolean isAlphaCharacter(String a) {
        boolean valid = false;
        for (char i : a.toCharArray()) {
            if (!Character.isDigit(i)) {
                valid = true;
            }
        }
        return valid;
    }

    //Setting de los paneles
    private void setPanels(int i) {
        view.mainArea.btnSteps = i;
        view.mainArea.activatePanels();
    }

    //Setting de los campos en 0 o ""
    private void setZero() {
        view.mainArea.sizeSet.txtHeight.setText("");
        view.mainArea.sizeSet.txtBase.setText("");
        view.mainArea.time.setHourS(0);
        view.mainArea.time.setMinuteS(0);
        view.mainArea.time.setHourE(0);
        view.mainArea.time.setMinuteE(0);
        view.mainArea.plants.cbGrass.setSelected(false);
        view.mainArea.plants.cbSmallTrees.setSelected(false);
        view.mainArea.plants.cbTrees.setSelected(false);
        view.mainArea.plants.cbVariousPlants.setSelected(false);
    }
}
