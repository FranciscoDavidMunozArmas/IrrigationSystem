package Controller;

import Classes.ArduinoInit;
import IrrigationInterface.IrrigationInterface;
import Model.ArduinoDAO;
import Model.ArduinoVo;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.table.DefaultTableModel;
//Controlador de la intefaz de los datos
public class ControllerData {

    private IrrigationInterface view;
    private ArduinoDAO dao;
    private ArduinoInit arduino;

    public ControllerData(IrrigationInterface view, ArduinoDAO dao, ArduinoInit arduino) {
        this.view = view;
        this.dao = dao;
        this.arduino = arduino;
        popUpTable();
    }
    //Actualizacion de la tabla o mostrar la tabla
    public void showTable() {
        fillTable(dao.getArduino());
    }
    //Llenar tablas
    private void fillTable(List<ArduinoVo> list) {
        DefaultTableModel model = view.dataInterface.getModel();
        model.setRowCount(0);
        view.dataInterface.jTable1.setModel(model);
        if (list.isEmpty()) {
            JOptionPane.showMessageDialog(null, "NO HAY DATOS DISPONIBLES");
        } else {
            for (ArduinoVo aux : list) {
                String startHour = "" + aux.getStartHour(), startMinute = "" + aux.getStartMinute(), endHour = "" + aux.getEndHour(), endMinute = "" + aux.getEndMinute();
                if (aux.getStartHour() < 10) {
                    startHour = "0" + aux.getStartHour();
                }
                if (aux.getStartMinute() < 10) {
                    startMinute = "0" + aux.getStartMinute();
                }
                if (aux.getEndHour() < 10) {
                    endHour = "0" + aux.getEndHour();
                }
                if (aux.getEndMinute() < 10) {
                    endMinute = "0" + aux.getEndMinute();
                }
                model.addRow(new Object[]{String.format("%.2f", aux.getLitres()), startHour + ":" + startMinute, endHour + ":" + endMinute});
            }
            view.dataInterface.jTable1.setModel(model);
        }
    }
    
    private void popUpTable() {
        JPopupMenu popUp = new JPopupMenu();
        JMenuItem set = new JMenuItem("SET");
        JMenuItem delete = new JMenuItem("DELETE");

        set.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (arduino.arduinoStartSend()) {
                    List<ArduinoVo> list = dao.getArduino();
                    if (arduino.arduinoSendData(list.get(view.dataInterface.jTable1.getSelectedRow()).toString())) {
                        JOptionPane.showMessageDialog(null, "DATOS ENVIADOS");
                    }
                    arduino.arduinoClose();
                }
            }
        });

        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int i = JOptionPane.showConfirmDialog(null, "Esta seguro que quiere borrar el dato?");
                if (i == 0) {
                    dao.deleteArduino(dao.getArduino().get(view.dataInterface.jTable1.getSelectedRow()).getId());
                    fillTable(dao.getArduino());
                }
            }
        });

        popUp.add(set);
        popUp.add(delete);
        view.dataInterface.jTable1.setComponentPopupMenu(popUp);
    }

}
