package Controller;

import Classes.ArduinoInit;
import IrrigationInterface.*;
import Model.ArduinoDAO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
//Controlador principal
public class Controller implements ActionListener {

    private IrrigationInterface view;
    private ArduinoDAO dao;
    private ArduinoInit arduino;

    public Controller(IrrigationInterface view, ArduinoDAO dao, ArduinoInit arduino) {
        this.view = view;
        this.dao = dao;
        this.arduino = arduino;
        this.view.btnIrrigationCalculate.addActionListener(this);
        this.view.btnDataStore.addActionListener(this);
        this.view.btnEmergencyClose.addActionListener(this);
        initComponents();
    }

    public void initComponents() {
        view.setResizable(false);
        view.setVisible(true);
        view.setLocationRelativeTo(null);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource().equals(view.btnIrrigationCalculate)) {
            (new ControllerArea(view, dao, arduino)).actionPerformed(e);
        }

        if (e.getSource().equals(view.btnDataStore)) {
            (new ControllerData(view, dao, arduino)).showTable();
        }

        if (e.getSource().equals(view.btnEmergencyClose)) {
            int i = JOptionPane.showConfirmDialog(null, "SE VA A CERRAR");
            if (i == 0) {
                if (arduino.arduinoStartSend()) {
                    if (arduino.arduinoSendData("c")) {
                        JOptionPane.showMessageDialog(null, "SE HA CERRADO");
                    }
                    arduino.arduinoClose();
                }
            }
        }
    }

}
