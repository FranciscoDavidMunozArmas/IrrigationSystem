package Model;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import static com.mongodb.client.model.Filters.eq;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;
import org.bson.types.ObjectId;

public class ArduinoDAO {
    //Comunicacion entre la interfaz y la base de datos
    public List<ArduinoVo> getArduino(){
        List<ArduinoVo> auxList = new ArrayList<ArduinoVo>();
        MongoCursor<Document> myDoc = (Connection.getInstance().getConnection()).find().iterator();
        while(myDoc.hasNext()){
            Document auxDoc = myDoc.next();
            auxList.add(new ArduinoVo(auxDoc.getObjectId("_id"),Double.parseDouble(auxDoc.get("litres").toString()), Integer.parseInt(auxDoc.get("Start Hour").toString()),Integer.parseInt(auxDoc.get("Start Minute").toString()), Integer.parseInt(auxDoc.get("End Hour").toString()),Integer.parseInt(auxDoc.get("End Minute").toString())));
        }
        return auxList;
    }
    
    public void deleteArduino(ObjectId _id){
        MongoCollection<Document> collection = Connection.getInstance().getConnection();
        collection.deleteOne(eq("_id", _id));
    } 
    
    public void putArduino(Object _id, Object litres, Object startHour, Object startMinute, Object endHour, Object endMinute){
        MongoCollection<Document> collection = Connection.getInstance().getConnection();
        collection.updateOne(eq("_id", _id), new Document("$set",new Document("litres", litres).append("Start Hour", startHour).append("Start Minute", startMinute).append("End Hour", endHour).append("End Minute", endMinute)));
    }
    
    public void postArduino(Object litres, Object startHour, Object startMinute, Object endHour, Object endMinute){
        MongoCollection<Document> collection = Connection.getInstance().getConnection();
        collection.insertOne(new Document("litres", litres).append("Start Hour", startHour).append("Start Minute", startMinute).append("End Hour", endHour).append("End Minute", endMinute));
    }
    
}
