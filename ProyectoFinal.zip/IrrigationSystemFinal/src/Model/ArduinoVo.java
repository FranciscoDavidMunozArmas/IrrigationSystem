package Model;

import org.bson.types.ObjectId;

public class ArduinoVo {

    private ObjectId _id;
    private double litres;
    private int startHour, startMinute, endHour, endMinute;

    public ArduinoVo(ObjectId _id, double litres, int startHour, int startMinute, int endHour, int endMinute) {
        this._id = _id;
        this.litres = litres;
        this.startHour = startHour;
        this.startMinute = startMinute;
        this.endHour = endHour;
        this.endMinute = endMinute;
    }

    public ObjectId getId() {
        return _id;
    }

    public double getLitres() {
        return litres;
    }

    public void setLitres(double litres) {
        this.litres = litres;
    }

    public int getStartHour() {
        return startHour;
    }

    public void setStartHour(int startHour) {
        this.startHour = startHour;
    }

    public int getStartMinute() {
        return startMinute;
    }

    public void setStartMinute(int startMinute) {
        this.startMinute = startMinute;
    }

    public int getEndHour() {
        return endHour;
    }

    public void setEndHour(int endHour) {
        this.endHour = endHour;
    }

    public int getEndMinute() {
        return endMinute;
    }

    public void setEndMinute(int endMinute) {
        this.endMinute = endMinute;
    }

    @Override
    public String toString() {
        return String.format("%.2f", litres) + "%" + startHour + "%" + startMinute + "%" + endHour + "%" + endMinute;
    }

}
