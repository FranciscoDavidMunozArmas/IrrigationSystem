package IrrigationInterface;

import Classes.ResizeIcons;
import java.awt.Color;
import javax.swing.ImageIcon;

public class IrrigationInterface extends javax.swing.JFrame {

    public IrrigationInterface() {
        initComponents();
        setIconImage(new ImageIcon(getClass().getResource("../Resources/MainIcon.png")).getImage());
        this.setLocationRelativeTo(null);
        ResizeIcons.resizeIcon(btnIrrigationCalculate);
        ResizeIcons.resizeIcon(btnDataStore);
        ResizeIcons.resizeIcon(btnEmergencyClose);
        jMainPanel.add(start);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMainPanel = new javax.swing.JPanel();
        panelMenu = new javax.swing.JPanel();
        btnIrrigationCalculate = new javax.swing.JButton();
        btnDataStore = new javax.swing.JButton();
        btnEmergencyClose = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jMainPanel.setBackground(new java.awt.Color(255, 255, 255));
        jMainPanel.setLayout(new java.awt.BorderLayout());

        panelMenu.setBackground(new java.awt.Color(255, 255, 255));

        btnIrrigationCalculate.setBackground(new java.awt.Color(255, 255, 255));
        btnIrrigationCalculate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/SetIcon.png"))); // NOI18N
        btnIrrigationCalculate.setBorderPainted(false);
        btnIrrigationCalculate.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnIrrigationCalculate.setPreferredSize(new java.awt.Dimension(40, 40));
        btnIrrigationCalculate.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnIrrigationCalculateMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnIrrigationCalculateMouseEntered(evt);
            }
        });
        btnIrrigationCalculate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIrrigationCalculateActionPerformed(evt);
            }
        });
        panelMenu.add(btnIrrigationCalculate);

        btnDataStore.setBackground(new java.awt.Color(255, 255, 255));
        btnDataStore.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/SaveDataIcon.png"))); // NOI18N
        btnDataStore.setBorderPainted(false);
        btnDataStore.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnDataStore.setPreferredSize(new java.awt.Dimension(40, 40));
        btnDataStore.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnDataStoreMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnDataStoreMouseEntered(evt);
            }
        });
        btnDataStore.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDataStoreActionPerformed(evt);
            }
        });
        panelMenu.add(btnDataStore);

        btnEmergencyClose.setBackground(new java.awt.Color(255, 255, 255));
        btnEmergencyClose.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/CloseIcon.png"))); // NOI18N
        btnEmergencyClose.setToolTipText("");
        btnEmergencyClose.setBorderPainted(false);
        btnEmergencyClose.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEmergencyClose.setPreferredSize(new java.awt.Dimension(40, 40));
        btnEmergencyClose.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnEmergencyCloseMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnEmergencyCloseMouseEntered(evt);
            }
        });
        panelMenu.add(btnEmergencyClose);

        jMainPanel.add(panelMenu, java.awt.BorderLayout.PAGE_END);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jMainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 379, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jMainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnIrrigationCalculateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIrrigationCalculateActionPerformed
        jMainPanel.add(mainArea);
        mainArea.setVisible(true);
        dataInterface.setVisible(false);
        start.setVisible(false);
    }//GEN-LAST:event_btnIrrigationCalculateActionPerformed

    private void btnDataStoreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDataStoreActionPerformed
        jMainPanel.add(dataInterface);
        mainArea.setVisible(false);
        dataInterface.setVisible(true);
        start.setVisible(false);
    }//GEN-LAST:event_btnDataStoreActionPerformed

    private void btnIrrigationCalculateMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnIrrigationCalculateMouseEntered
        btnIrrigationCalculate.setBackground(Color.LIGHT_GRAY);
    }//GEN-LAST:event_btnIrrigationCalculateMouseEntered

    private void btnDataStoreMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnDataStoreMouseEntered
        btnDataStore.setBackground(Color.LIGHT_GRAY);
    }//GEN-LAST:event_btnDataStoreMouseEntered

    private void btnEmergencyCloseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEmergencyCloseMouseEntered
        btnEmergencyClose.setBackground(Color.LIGHT_GRAY);
    }//GEN-LAST:event_btnEmergencyCloseMouseEntered

    private void btnIrrigationCalculateMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnIrrigationCalculateMouseExited
        btnIrrigationCalculate.setBackground(Color.WHITE);
    }//GEN-LAST:event_btnIrrigationCalculateMouseExited

    private void btnDataStoreMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnDataStoreMouseExited
        btnDataStore.setBackground(Color.WHITE);
    }//GEN-LAST:event_btnDataStoreMouseExited

    private void btnEmergencyCloseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEmergencyCloseMouseExited
        btnEmergencyClose.setBackground(Color.WHITE);
    }//GEN-LAST:event_btnEmergencyCloseMouseExited

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(IrrigationInterface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(IrrigationInterface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(IrrigationInterface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(IrrigationInterface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new IrrigationInterface().setVisible(true);
            }
        });
    }
    public SetMenu mainArea = new SetMenu();
    public DataInterface dataInterface = new DataInterface();
    public StartPage start = new StartPage();
    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btnDataStore;
    public javax.swing.JButton btnEmergencyClose;
    public javax.swing.JButton btnIrrigationCalculate;
    private javax.swing.JPanel jMainPanel;
    private javax.swing.JPanel panelMenu;
    // End of variables declaration//GEN-END:variables

}
