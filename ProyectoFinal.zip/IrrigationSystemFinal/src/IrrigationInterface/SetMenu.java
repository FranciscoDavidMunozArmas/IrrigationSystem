package IrrigationInterface;

import Classes.ResizeIcons;

public class SetMenu extends javax.swing.JPanel {

    public SetMenu() {
        initComponents();
        changePanels();
        rbtnFigure.setEnabled(false);
        rbtnHours.setEnabled(false);
        rtbnArea.setEnabled(false);
        rtbnSelectPlant.setEnabled(false);
        enableButtons();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnGSteps = new javax.swing.ButtonGroup();
        conteiner = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        btnBackButton = new javax.swing.JButton();
        rbtnFigure = new javax.swing.JRadioButton();
        rtbnArea = new javax.swing.JRadioButton();
        rbtnHours = new javax.swing.JRadioButton();
        rtbnSelectPlant = new javax.swing.JRadioButton();
        btnNext = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(new java.awt.BorderLayout());

        conteiner.setBackground(new java.awt.Color(255, 255, 255));
        conteiner.setLayout(new java.awt.BorderLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        btnBackButton.setBackground(new java.awt.Color(255, 255, 255));
        btnBackButton.setText("<");
        btnBackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackButtonActionPerformed(evt);
            }
        });
        jPanel1.add(btnBackButton);

        rbtnFigure.setBackground(new java.awt.Color(255, 255, 255));
        btnGSteps.add(rbtnFigure);
        rbtnFigure.setSelected(true);
        jPanel1.add(rbtnFigure);

        rtbnArea.setBackground(new java.awt.Color(255, 255, 255));
        btnGSteps.add(rtbnArea);
        jPanel1.add(rtbnArea);

        rbtnHours.setBackground(new java.awt.Color(255, 255, 255));
        btnGSteps.add(rbtnHours);
        jPanel1.add(rbtnHours);

        rtbnSelectPlant.setBackground(new java.awt.Color(255, 255, 255));
        btnGSteps.add(rtbnSelectPlant);
        jPanel1.add(rtbnSelectPlant);

        btnNext.setBackground(new java.awt.Color(255, 255, 255));
        btnNext.setText(">");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });
        jPanel1.add(btnNext);

        conteiner.add(jPanel1, java.awt.BorderLayout.PAGE_END);

        add(conteiner, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackButtonActionPerformed
        ResizeIcons.setColor(btnBackButton, btnNext);
        btnSteps--;
        changePanels();
    }//GEN-LAST:event_btnBackButtonActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        ResizeIcons.setColor(btnNext, btnBackButton);
        btnSteps++;
        changePanels();
    }//GEN-LAST:event_btnNextActionPerformed

    public int btnSteps = 0;
    public SizeSet sizeSet = new SizeSet();
    public SetIrrigationTime time = new SetIrrigationTime();
    public SetPlantsForIrrigation plants = new SetPlantsForIrrigation();
    public SelectionArea selArea = new SelectionArea();
    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btnBackButton;
    private javax.swing.ButtonGroup btnGSteps;
    public javax.swing.JButton btnNext;
    public javax.swing.JPanel conteiner;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton rbtnFigure;
    private javax.swing.JRadioButton rbtnHours;
    private javax.swing.JRadioButton rtbnArea;
    private javax.swing.JRadioButton rtbnSelectPlant;
    // End of variables declaration//GEN-END:variables

    public void changePanels() {
        activatePanels();
        prooveCont();
    }

    private void prooveCont() {
        if (btnSteps > 4) {
            btnSteps = 4;
        } else if (btnSteps < 0) {
            btnSteps = 0;
        }
    }
    //Cambio entre paneles
    public void activatePanels() {
        enableButtons();
        switch (btnSteps) {
            case 0:
                conteiner.add(selArea);
                btnGSteps.clearSelection();
                rbtnFigure.setSelected(true);
                selArea.setVisible(true);
                sizeSet.setVisible(false);
                time.setVisible(false);
                plants.setVisible(false);
                conteiner.validate();
                break;
            case 1:
                conteiner.add(sizeSet);
                btnGSteps.clearSelection();
                rtbnArea.setSelected(true);
                selArea.setVisible(false);
                sizeSet.setVisible(true);
                time.setVisible(false);
                plants.setVisible(false);
                conteiner.validate();
                break;
            case 2:
                conteiner.add(time);
                btnGSteps.clearSelection();
                rbtnHours.setSelected(true);
                selArea.setVisible(false);
                sizeSet.setVisible(false);
                time.setVisible(true);
                plants.setVisible(false);
                conteiner.validate();
                break;
            case 3:
                conteiner.add(plants);
                btnGSteps.clearSelection();
                rtbnSelectPlant.setSelected(true);
                selArea.setVisible(false);
                sizeSet.setVisible(false);
                time.setVisible(false);
                plants.setVisible(true);
                conteiner.validate();
                break;
        }

    }
    //Habilitar y deshabilitar botones
    public void enableButtons() {

        if (btnSteps <= 0) {
            btnNext.setText(">");
            btnNext.setEnabled(false);
            btnBackButton.setEnabled(false);
        } else if (btnSteps == 3) {
            btnNext.setText("CALCULAR");
        } else {
            btnNext.setText(">");
            btnNext.setEnabled(true);
            btnBackButton.setEnabled(true);
        }
    }
}
