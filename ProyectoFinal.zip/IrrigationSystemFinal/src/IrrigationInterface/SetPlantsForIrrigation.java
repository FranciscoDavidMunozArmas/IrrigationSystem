package IrrigationInterface;

public class SetPlantsForIrrigation extends javax.swing.JPanel {

    public SetPlantsForIrrigation() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cbTrees = new javax.swing.JCheckBox();
        cbSmallTrees = new javax.swing.JCheckBox();
        cbVariousPlants = new javax.swing.JCheckBox();
        cbGrass = new javax.swing.JCheckBox();

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(370, 276));

        cbTrees.setBackground(new java.awt.Color(255, 255, 255));
        cbTrees.setText("Arboles");

        cbSmallTrees.setBackground(new java.awt.Color(255, 255, 255));
        cbSmallTrees.setText("Arbustos");

        cbVariousPlants.setBackground(new java.awt.Color(255, 255, 255));
        cbVariousPlants.setText("Plantas Varias");

        cbGrass.setBackground(new java.awt.Color(255, 255, 255));
        cbGrass.setText("Cesped");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(144, 144, 144)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cbGrass)
                    .addComponent(cbVariousPlants)
                    .addComponent(cbSmallTrees)
                    .addComponent(cbTrees))
                .addContainerGap(163, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addComponent(cbGrass)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbTrees)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbSmallTrees)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbVariousPlants)
                .addContainerGap(145, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JCheckBox cbGrass;
    public javax.swing.JCheckBox cbSmallTrees;
    public javax.swing.JCheckBox cbTrees;
    public javax.swing.JCheckBox cbVariousPlants;
    // End of variables declaration//GEN-END:variables
}
