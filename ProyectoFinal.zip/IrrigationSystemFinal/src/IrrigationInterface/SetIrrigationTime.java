package IrrigationInterface;

import Classes.ResizeIcons;
import java.awt.Color;

public class SetIrrigationTime extends javax.swing.JPanel {

    public SetIrrigationTime() {
        initComponents();
        setHour(hourS, minuteS, lStartHour);
        setHour(hourE, minuteE, lEndtHour);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lStartHour = new javax.swing.JLabel();
        btnAddH = new javax.swing.JButton();
        btnAddM = new javax.swing.JButton();
        btnReduceH = new javax.swing.JButton();
        btnReduceM = new javax.swing.JButton();
        lEndtHour = new javax.swing.JLabel();
        btnAddM1 = new javax.swing.JButton();
        btnAddH1 = new javax.swing.JButton();
        btnReduceH1 = new javax.swing.JButton();
        btnReduceM1 = new javax.swing.JButton();
        lStartHour1 = new javax.swing.JLabel();
        lEndtHour1 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));

        lStartHour.setBackground(new java.awt.Color(255, 255, 255));
        lStartHour.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lStartHour.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lStartHour.setText("0:0");

        btnAddH.setBackground(new java.awt.Color(255, 255, 255));
        btnAddH.setText("+");
        btnAddH.setBorder(null);
        btnAddH.setPreferredSize(new java.awt.Dimension(25, 50));
        btnAddH.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnAddHMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAddHMouseEntered(evt);
            }
        });
        btnAddH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddHActionPerformed(evt);
            }
        });

        btnAddM.setBackground(new java.awt.Color(255, 255, 255));
        btnAddM.setText("+");
        btnAddM.setBorder(null);
        btnAddM.setPreferredSize(new java.awt.Dimension(25, 50));
        btnAddM.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnAddMMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAddMMouseEntered(evt);
            }
        });
        btnAddM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddMActionPerformed(evt);
            }
        });

        btnReduceH.setBackground(new java.awt.Color(255, 255, 255));
        btnReduceH.setText("-");
        btnReduceH.setBorder(null);
        btnReduceH.setPreferredSize(new java.awt.Dimension(25, 50));
        btnReduceH.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnReduceHMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnReduceHMouseEntered(evt);
            }
        });
        btnReduceH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReduceHActionPerformed(evt);
            }
        });

        btnReduceM.setBackground(new java.awt.Color(255, 255, 255));
        btnReduceM.setText("-");
        btnReduceM.setBorder(null);
        btnReduceM.setPreferredSize(new java.awt.Dimension(25, 50));
        btnReduceM.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnReduceMMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnReduceMMouseEntered(evt);
            }
        });
        btnReduceM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReduceMActionPerformed(evt);
            }
        });

        lEndtHour.setBackground(new java.awt.Color(255, 255, 255));
        lEndtHour.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lEndtHour.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lEndtHour.setText("0:0");

        btnAddM1.setBackground(new java.awt.Color(255, 255, 255));
        btnAddM1.setText("+");
        btnAddM1.setBorder(null);
        btnAddM1.setPreferredSize(new java.awt.Dimension(25, 50));
        btnAddM1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnAddM1MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAddM1MouseEntered(evt);
            }
        });
        btnAddM1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddM1ActionPerformed(evt);
            }
        });

        btnAddH1.setBackground(new java.awt.Color(255, 255, 255));
        btnAddH1.setText("+");
        btnAddH1.setBorder(null);
        btnAddH1.setPreferredSize(new java.awt.Dimension(25, 50));
        btnAddH1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnAddH1MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAddH1MouseEntered(evt);
            }
        });
        btnAddH1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddH1ActionPerformed(evt);
            }
        });

        btnReduceH1.setBackground(new java.awt.Color(255, 255, 255));
        btnReduceH1.setText("-");
        btnReduceH1.setBorder(null);
        btnReduceH1.setPreferredSize(new java.awt.Dimension(25, 50));
        btnReduceH1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnReduceH1MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnReduceH1MouseEntered(evt);
            }
        });
        btnReduceH1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReduceH1ActionPerformed(evt);
            }
        });

        btnReduceM1.setBackground(new java.awt.Color(255, 255, 255));
        btnReduceM1.setText("-");
        btnReduceM1.setBorder(null);
        btnReduceM1.setPreferredSize(new java.awt.Dimension(25, 50));
        btnReduceM1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnReduceM1MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnReduceM1MouseEntered(evt);
            }
        });
        btnReduceM1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReduceM1ActionPerformed(evt);
            }
        });

        lStartHour1.setBackground(new java.awt.Color(255, 255, 255));
        lStartHour1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lStartHour1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lStartHour1.setText("INICIO");

        lEndtHour1.setBackground(new java.awt.Color(255, 255, 255));
        lEndtHour1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lEndtHour1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lEndtHour1.setText("FIN");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(85, 85, 85)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lStartHour1, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39)
                        .addComponent(lEndtHour1, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(btnReduceH, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnReduceM, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(btnAddH, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnAddM, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lStartHour, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(39, 39, 39)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(btnReduceH1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(btnReduceM1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(lEndtHour, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnAddH1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnAddM1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(138, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lStartHour1)
                    .addComponent(lEndtHour1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnReduceH1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnReduceM, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnReduceH, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnReduceM1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lStartHour)
                    .addComponent(lEndtHour))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnAddH1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnAddH, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnAddM, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnAddM1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(84, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnReduceHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReduceHActionPerformed
        hourS--;
        hourS = hourRange(hourS);
        setHour(hourS, minuteS, lStartHour);
    }//GEN-LAST:event_btnReduceHActionPerformed

    private void btnAddHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddHActionPerformed
        hourS++;
        hourS = hourRange(hourS);
        setHour(hourS, minuteS, lStartHour);
    }//GEN-LAST:event_btnAddHActionPerformed

    private void btnReduceMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReduceMActionPerformed
        minuteS--;
        minuteS = minuteRange(minuteS);
        setHour(hourS, minuteS, lStartHour);
    }//GEN-LAST:event_btnReduceMActionPerformed

    private void btnAddMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddMActionPerformed
        minuteS++;
        minuteS = minuteRange(minuteS);
        setHour(hourS, minuteS, lStartHour);
    }//GEN-LAST:event_btnAddMActionPerformed

    private void btnReduceH1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReduceH1ActionPerformed
        hourE--;
        hourE = hourRange(hourE);
        setHour(hourE, minuteE, lEndtHour);
    }//GEN-LAST:event_btnReduceH1ActionPerformed

    private void btnAddH1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddH1ActionPerformed
        hourE++;
        hourE = hourRange(hourE);
        setHour(hourE, minuteE, lEndtHour);
    }//GEN-LAST:event_btnAddH1ActionPerformed

    private void btnReduceM1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReduceM1ActionPerformed
        minuteE--;
        minuteE = minuteRange(minuteE);
        setHour(hourE, minuteE, lEndtHour);
    }//GEN-LAST:event_btnReduceM1ActionPerformed

    private void btnAddM1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddM1ActionPerformed
        minuteE++;
        minuteE = minuteRange(minuteE);
        setHour(hourE, minuteE, lEndtHour);
    }//GEN-LAST:event_btnAddM1ActionPerformed

    private void btnReduceHMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnReduceHMouseEntered
        btnReduceH.setBackground(Color.LIGHT_GRAY);
    }//GEN-LAST:event_btnReduceHMouseEntered

    private void btnReduceHMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnReduceHMouseExited
        btnReduceH.setBackground(Color.WHITE);
    }//GEN-LAST:event_btnReduceHMouseExited

    private void btnReduceMMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnReduceMMouseEntered
        btnReduceM.setBackground(Color.LIGHT_GRAY);
    }//GEN-LAST:event_btnReduceMMouseEntered

    private void btnReduceMMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnReduceMMouseExited
        btnReduceM.setBackground(Color.WHITE);
    }//GEN-LAST:event_btnReduceMMouseExited

    private void btnReduceH1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnReduceH1MouseEntered
        btnReduceH1.setBackground(Color.LIGHT_GRAY);
    }//GEN-LAST:event_btnReduceH1MouseEntered

    private void btnReduceH1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnReduceH1MouseExited
        btnReduceH1.setBackground(Color.WHITE);
    }//GEN-LAST:event_btnReduceH1MouseExited

    private void btnReduceM1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnReduceM1MouseEntered
        btnReduceM1.setBackground(Color.LIGHT_GRAY);
    }//GEN-LAST:event_btnReduceM1MouseEntered

    private void btnReduceM1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnReduceM1MouseExited
        btnReduceM1.setBackground(Color.WHITE);
    }//GEN-LAST:event_btnReduceM1MouseExited

    private void btnAddHMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAddHMouseEntered
        btnAddH.setBackground(Color.LIGHT_GRAY);
    }//GEN-LAST:event_btnAddHMouseEntered

    private void btnAddHMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAddHMouseExited
        btnAddH.setBackground(Color.WHITE);
    }//GEN-LAST:event_btnAddHMouseExited

    private void btnAddMMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAddMMouseEntered
        btnAddM.setBackground(Color.LIGHT_GRAY);
    }//GEN-LAST:event_btnAddMMouseEntered

    private void btnAddMMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAddMMouseExited
        btnAddM.setBackground(Color.WHITE);
    }//GEN-LAST:event_btnAddMMouseExited

    private void btnAddH1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAddH1MouseEntered
        btnAddH1.setBackground(Color.LIGHT_GRAY);
    }//GEN-LAST:event_btnAddH1MouseEntered

    private void btnAddH1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAddH1MouseExited
        btnAddH1.setBackground(Color.WHITE);
    }//GEN-LAST:event_btnAddH1MouseExited

    private void btnAddM1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAddM1MouseEntered
        btnAddM1.setBackground(Color.LIGHT_GRAY);
    }//GEN-LAST:event_btnAddM1MouseEntered

    private void btnAddM1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAddM1MouseExited
        btnAddM1.setBackground(Color.WHITE);
    }//GEN-LAST:event_btnAddM1MouseExited

    private int hourS = 0, minuteS = 0, hourE = 0, minuteE = 0;
    private String hour, minute;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddH;
    private javax.swing.JButton btnAddH1;
    private javax.swing.JButton btnAddM;
    private javax.swing.JButton btnAddM1;
    private javax.swing.JButton btnReduceH;
    private javax.swing.JButton btnReduceH1;
    private javax.swing.JButton btnReduceM;
    private javax.swing.JButton btnReduceM1;
    private javax.swing.JLabel lEndtHour;
    private javax.swing.JLabel lEndtHour1;
    private javax.swing.JLabel lStartHour;
    private javax.swing.JLabel lStartHour1;
    // End of variables declaration//GEN-END:variables

    public int getHourS() {
        return hourS;
    }

    public int getMinuteS() {
        return minuteS;
    }

    public int getHourE() {
        return hourE;
    }

    public int getMinuteE() {
        return minuteE;
    }

    public void setHourS(int hourS) {
        this.hourS = hourS;
    }

    public void setMinuteS(int minuteS) {
        this.minuteS = minuteS;
    }

    public void setHourE(int hourE) {
        this.hourE = hourE;
    }

    public void setMinuteE(int minuteE) {
        this.minuteE = minuteE;
    }
    //Reestablecimiento de la hora
    private void setHour(int h, int m, javax.swing.JLabel a) {
        String hs = "" + h, ms = "" + m;
        if (h < 10) {
            hs = "0" + h;
        }
        if (m < 10) {
            ms = "0" + m;
        }
        a.setText(hs + ":" + ms);
    }

    private int hourRange(int h) {
        if (h > 23) {
            h = 0;
        }
        if (h < 0) {
            h = 23;
        }

        return h;
    }

    private int minuteRange(int m) {
        if (m > 59) {
            m = 0;
        }
        if (m < 0) {
            m = 59;
        }

        return m;
    }

}
