package IrrigationInterface;

import java.awt.Color;

public class SelectionArea extends javax.swing.JPanel {

    public SelectionArea() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnRectangle = new javax.swing.JButton();
        btnCircle = new javax.swing.JButton();
        btnTriangle = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));

        btnRectangle.setBackground(new java.awt.Color(255, 255, 255));
        btnRectangle.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/rectangulo.png"))); // NOI18N
        btnRectangle.setBorderPainted(false);
        btnRectangle.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnRectangleMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnRectangleMouseEntered(evt);
            }
        });

        btnCircle.setBackground(new java.awt.Color(255, 255, 255));
        btnCircle.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/circulo.png"))); // NOI18N
        btnCircle.setBorderPainted(false);
        btnCircle.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnCircleMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnCircleMouseEntered(evt);
            }
        });

        btnTriangle.setBackground(new java.awt.Color(255, 255, 255));
        btnTriangle.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/triangulo.png"))); // NOI18N
        btnTriangle.setBorderPainted(false);
        btnTriangle.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnTriangleMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnTriangleMouseEntered(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("SELECCIONE LA FORMA DE SU TERRENO:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(31, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnRectangle, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCircle, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnTriangle, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(27, 27, 27))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRectangle, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCircle, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTriangle, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(110, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnRectangleMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRectangleMouseEntered
        btnRectangle.setBackground(Color.LIGHT_GRAY);
    }//GEN-LAST:event_btnRectangleMouseEntered

    private void btnRectangleMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRectangleMouseExited
        btnRectangle.setBackground(Color.WHITE);
    }//GEN-LAST:event_btnRectangleMouseExited

    private void btnCircleMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCircleMouseEntered
        btnCircle.setBackground(Color.LIGHT_GRAY);
    }//GEN-LAST:event_btnCircleMouseEntered

    private void btnCircleMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCircleMouseExited
        btnCircle.setBackground(Color.WHITE);
    }//GEN-LAST:event_btnCircleMouseExited

    private void btnTriangleMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnTriangleMouseEntered
        btnTriangle.setBackground(Color.LIGHT_GRAY);
    }//GEN-LAST:event_btnTriangleMouseEntered

    private void btnTriangleMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnTriangleMouseExited
        btnTriangle.setBackground(Color.WHITE);
    }//GEN-LAST:event_btnTriangleMouseExited

    private int areaSelection;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btnCircle;
    public javax.swing.JButton btnRectangle;
    public javax.swing.JButton btnTriangle;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables

    public int getAreaSelection() {
        return areaSelection;
    }

    public void setAreaSelection(int areaSelection) {
        this.areaSelection = areaSelection;
    }
}
