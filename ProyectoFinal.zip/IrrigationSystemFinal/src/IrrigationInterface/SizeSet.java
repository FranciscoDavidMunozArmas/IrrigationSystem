package IrrigationInterface;

public class SizeSet extends javax.swing.JPanel {
    
    public SizeSet() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtHeight = new javax.swing.JTextField();
        txtBase = new javax.swing.JTextField();
        lbHeight = new javax.swing.JLabel();
        lbBase = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));

        lbHeight.setBackground(new java.awt.Color(255, 255, 255));
        lbHeight.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbHeight.setText("ALTURA");

        lbBase.setBackground(new java.awt.Color(255, 255, 255));
        lbBase.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbBase.setText("BASE");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtHeight)
                    .addComponent(txtBase)
                    .addComponent(lbBase, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbHeight, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 380, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(101, 101, 101)
                .addComponent(txtBase, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbBase)
                .addGap(29, 29, 29)
                .addComponent(txtHeight, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbHeight)
                .addContainerGap(102, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JLabel lbBase;
    public javax.swing.JLabel lbHeight;
    public javax.swing.JTextField txtBase;
    public javax.swing.JTextField txtHeight;
    // End of variables declaration//GEN-END:variables
}
