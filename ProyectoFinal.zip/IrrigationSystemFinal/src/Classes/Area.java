package Classes;

public abstract class Area{
    private double side;

    public Area(double side) {
        this.side = side;
    }

    public abstract double area();

    public double getSide() {
        return side;
    }

    public void setSide(double side) {
        this.side = side;
    }
    
}