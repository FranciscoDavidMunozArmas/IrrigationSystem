package Classes;

public class FlowForArduino {
    //El caudal se calcula mediante los litros sobre el tiempo
    public static double getFlow(double litres, double area, int minutes) {
        return ((litres*area)/minutes);
    }    
}