package Classes;

import com.panamahitek.ArduinoException;
import com.panamahitek.PanamaHitek_Arduino;
import com.panamahitek.PanamaHitek_MultiMessage;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import jssc.SerialPortEvent;
import jssc.SerialPortEventListener;
import jssc.SerialPortException;

//Clase creada para facilitar la comunicacion con arduino
public class ArduinoInit {

    private PanamaHitek_Arduino ino = new PanamaHitek_Arduino();
    private PanamaHitek_MultiMessage mIno = new PanamaHitek_MultiMessage(1, ino);
    private SerialPortEventListener event = new SerialPortEventListener() {
        @Override
        public void serialEvent(SerialPortEvent spe) {
            try {
                if (mIno.dataReceptionCompleted()) {
                    System.out.println(mIno.getMessage(0));
                    mIno.flushBuffer();
                }
            } catch (ArduinoException ex) {
                Logger.getLogger(ArduinoInit.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SerialPortException ex) {
                Logger.getLogger(ArduinoInit.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    };
    
    //Inicio de la conexion de arduino unicamente para el envio de datos
    public boolean arduinoStartSend() {
        boolean send = false;
        do {
            try {
                ino.arduinoTX("COM3", 9600);
                send = true;
                break;
            } catch (ArduinoException ex) {
                int i = JOptionPane.showConfirmDialog(null, "Error de conexion\n¿Volver a intentar?");
                if (i == 1) {
                    break;
                }
                Logger.getLogger(ArduinoInit.class.getName()).log(Level.SEVERE, null, ex);
            }

        } while (true);
        return send;
    }
    
    //Inicio de la conexion de arduino unicamente para la recepcion y envio de datos
    public void arduinoStartSendReciveData() {
        try {
            ino.arduinoRXTX("COM3", 9600, event);
        } catch (ArduinoException ex) {
            Logger.getLogger(ArduinoInit.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //Envio de datos a arduino
    public boolean arduinoSendData(String data) {
        boolean send = false;
        System.out.println(data);
        do {
            try {
                ino.sendData(data);
                send = true;
                break;
            } catch (ArduinoException | SerialPortException ex) {
                int i = JOptionPane.showConfirmDialog(null, "Error al Enviar Datos\n¿Volver a intentar?");
                if (i == 1) {
                    break;
                }
                Logger.getLogger(ArduinoInit.class.getName()).log(Level.SEVERE, null, ex);
            }
        } while (true);
        return send;
    }
    
    //Inicio de la conexion de arduino unicamente para la recepcion de datos
    public void arduinoGetData() {
        try {
            ino.arduinoRX("COM3", 9600, event);
        } catch (ArduinoException ex) {
            Logger.getLogger(ArduinoInit.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SerialPortException ex) {
            Logger.getLogger(ArduinoInit.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //Fin de la conexion con arduino
    public void arduinoClose() {
        try {
            ino.killArduinoConnection();
        } catch (ArduinoException ex) {
            Logger.getLogger(ArduinoInit.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
