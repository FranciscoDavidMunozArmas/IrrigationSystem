package Classes;

public class Time {

    //Transformacion de horas a minutos
    public static int toMinutes(int hours, int minutes) {
        return (minutes + (hours * 60));
    }
    //Obtencion de la diferencia entre el tiempo
    public static int getDiference(int SHours, int SMinutes, int EHours, int EMinutes) {
        return toMinutes(EHours, EMinutes) - toMinutes(SHours, SMinutes);
    }
    //Obtencion de la diferencia entre el tiempo
    public static int getDiference(int SMinutes, int EMinutes) {
        return EMinutes - SMinutes;
    }
}
