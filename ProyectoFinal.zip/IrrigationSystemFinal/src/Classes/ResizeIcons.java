package Classes;

import java.awt.Color;
import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
//Clase creada para los botones y sus iconos
public class ResizeIcons {

    public static void setColor(JButton a, JButton b) {
        a.setBackground(Color.LIGHT_GRAY);
        b.setBackground(Color.WHITE);
    }
    //Redimension de iconos de botones
    public static void resizeIcon(JButton a) {
        ImageIcon img = new ImageIcon(getPath(a.getIcon().toString()));
        Icon icon = new ImageIcon(img.getImage().getScaledInstance(a.getWidth()+15, a.getHeight()+15, Image.SCALE_SMOOTH));
        a.setIcon(icon);
    }
    //Redimension de iconos de labels
    public static void resizeIcon(JLabel a) {
        ImageIcon img = new ImageIcon(getPath(a.getIcon().toString()));
        Icon icon = new ImageIcon(img.getImage().getScaledInstance(300, 250, Image.SCALE_SMOOTH));
        a.setIcon(icon);
    }
    //Se obtiene el path de los iconos
    private static String getPath(String a){
        String aux = "";
        char[] auxString = a.toCharArray();
        for(int i = 6; i < auxString.length; i++){
            aux += "" + auxString[i];
        }
        return aux;
    }
}