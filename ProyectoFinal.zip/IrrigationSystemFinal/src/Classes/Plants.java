package Classes;

public class Plants{
    //Constante de evaporacion, necesario sumarlo
    final private double evt = 3.5;
    //Litros para un arbol
    public double getLitresPerTree(){
        return (2.4+evt);
    }
    //Litros para un arbusto
    public double getLitresPerShortTree(){
        return (1.6+evt);
    }
    //Litros para cesped y otros tipos de plantas
    public double getLitresPerGrassOrVariousTypeOfPlants(){
        return (2.5+evt);
    }
}