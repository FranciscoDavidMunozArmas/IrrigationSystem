package Classes;

public class AreaCircle extends Area{

    public AreaCircle(double side) {
        super(side);
    }

    @Override
    public double area(){
        return getSide()*getSide()*Math.PI;
    }
}