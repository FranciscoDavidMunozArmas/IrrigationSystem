package Classes;

public class AreaRectangle extends Area{
    
    private double height;

    public AreaRectangle(double height, double side) {
        super(side);
        this.height = height;
    }

    @Override
    public double area(){
        return getSide()*height;
    }

    public double getHeight() {
        return height;
    }
}