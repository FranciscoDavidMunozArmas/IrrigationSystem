package Classes;

public class AreaTriangle extends Area{
    
    private double height;

    public AreaTriangle(double height, double side) {
        super(side);
        this.height = height;
    }
    
    public double getHeight() {
        return height;
    }
    
    @Override
    public double area(){
        return (getSide()*height)/2;
    }
}